package com.example.myparcelapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Message
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.android.synthetic.main.activity_html.*



class HtmlActivity : AppCompatActivity(), Runnable {

    var str: String? = null
    var handler : Handler = object : Handler() {
        // Alt + Enter -> Override Methods
        // 백그라운드 스레드에서 전달된 메시지를 처리하는 method
        override fun handleMessage(msg: Message?) {
            super.handleMessage(msg)
            edit1.setText(str)
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_html)

        button1.setOnClickListener(({
            // 메인스레드 외에 백그라운드에서 실행되는 스레드 추가
            val th = Thread(this@HtmlActivity)
            th.start()
        }))

    }



    override fun run(){
        //http://192.168.55.231:8080/
        str = download()
        edit1.setText(str)
        handler.sendEmptyMessage(0)
    }



    fun download(): String {
        val sb = StringBuffer()
        try {
            // 호출할 spring 서버측 주소 입력(URL주소 형태로 객체화)
            val url = URL("http://192.168.55.231:8080/")
            // url에 접속 객체 가져오기
            val conn = url.openConnection() as HttpURLConnection
            if (conn != null) {
                conn.connectTimeout = 5000
                conn.useCaches = false
                if (conn.responseCode == 200) {
                    val br = BufferedReader(InputStreamReader(conn.inputStream, "utf-8"))
                    while (true) { // 무한 반복
                        val line = br.readLine() ?: break // 한줄 읽기
// 더이상 내용이 없으면 루프 종료
                        sb.append(line + "\n")
                    }
                    br.close() // 버퍼 닫기
                }
                conn.disconnect() // 연결 종료
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        // 가져와 append한 내용을 리턴
        return sb.toString()

    }
}
